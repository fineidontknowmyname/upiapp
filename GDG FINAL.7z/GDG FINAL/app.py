import os
import logging
from flask import Flask, render_template, redirect, url_for, flash
from flask_wtf.csrf import CSRFProtect
from config import DevelopmentConfig, ProductionConfig, TestingConfig
from routes.auth_routes import auth_bp
from routes.scan_routes import scan_bp
from routes.admin_routes import admin_bp

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def create_app():
    app = Flask(__name__)
    
    # Load configuration based on environment
    env = os.environ.get('FLASK_ENV', 'development')
    if env == 'production':
        app.config.from_object(ProductionConfig)
    elif env == 'testing':
        app.config.from_object(TestingConfig)
    else:
        app.config.from_object(DevelopmentConfig)
    
    # Initialize CSRF protection
    csrf = CSRFProtect(app)
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(scan_bp, url_prefix='/scan')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    
    # Root route
    @app.route('/')
    def index():
        return redirect(url_for('scan.index'))
    
    # Error handlers
    @app.errorhandler(403)
    def forbidden_error(e):
        logging.warning(f"403 Forbidden: {e}")
        return render_template('error.html', error="403 Forbidden"), 403
    
    @app.errorhandler(404)
    def not_found_error(e):
        logging.warning(f"404 Not Found: {e}")
        return render_template('error.html', error="404 Not Found"), 404
    
    @app.errorhandler(500)
    def internal_server_error(e):
        logging.error(f"500 Internal Server Error: {e}")
        return render_template('error.html', error="500 Internal Server Error"), 500
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=app.config['DEBUG'], host='0.0.0.0', port=5000)
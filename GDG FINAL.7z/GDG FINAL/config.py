import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    # Ensure this key is securely generated in production
    SECRET_KEY = os.environ.get('FLASK_SECRET_KEY', 'default_secret_key_for_development_only')
    DEBUG = False
    TESTING = False
    # Set session type to filesystem for better security
    SESSION_TYPE = 'filesystem'
    # Ensure sessions are secure
    SESSION_COOKIE_SECURE = True
    # Prevent JavaScript from accessing cookies
    SESSION_COOKIE_HTTPONLY = True
    # Set session lifetime
    PERMANENT_SESSION_LIFETIME = 1800  # 30 minutes

class DevelopmentConfig(Config):
    DEBUG = True
    ENV = 'development'
    # Override secure cookies for local development
    SESSION_COOKIE_SECURE = False

class ProductionConfig(Config):
    DEBUG = False
    ENV = 'production'
    # In production, ensure you have a proper secret key
    SESSION_COOKIE_SECURE = True

class TestingConfig(Config):
    TESTING = True
    DEBUG = True
    ENV = 'testing'
    # For testing, we can disable secure cookies
    SESSION_COOKIE_SECURE = False
    WTF_CSRF_ENABLED = False  # Disable CSRF for testing
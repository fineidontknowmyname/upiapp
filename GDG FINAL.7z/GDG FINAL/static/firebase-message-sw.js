// static/firebase-messaging-sw.js
importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js');

// Function to fetch environment variables from the server
async function getEnvVariables() {
  try {
    const response = await fetch('/get_env'); // Create a new route in app.py
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Failed to fetch environment variables:', error);
    return {};
  }
}

// Initialize Firebase app in the service worker
async function initializeFirebase() {
  const env = await getEnvVariables();
  const firebaseConfig = {
    apiKey: env.FIREBASE_API_KEY,
    authDomain: env.FIREBASE_AUTH_DOMAIN,
    projectId: env.FIREBASE_PROJECT_ID,
    messagingSenderId: env.FIREBASE_MESSAGING_SENDER_ID,
    appId: env.FIREBASE_APP_ID
  };

  firebase.initializeApp(firebaseConfig);
  const messaging = firebase.messaging();

  // Background message handling
  messaging.setBackgroundMessageHandler(function(payload) {
    console.log('[firebase-messaging-sw.js] Received background message ', payload);

    // Extract notification details from the payload
    const notificationTitle = payload.notification.title || "UPI Fraud Detection Alert";
    const notificationOptions = {
      body: payload.notification.body || "You have a new notification.",
      icon: '/static/notification-icon.png',
      click_action: payload.notification.click_action || '/'
    };

    // Show the notification
    return self.registration.showNotification(notificationTitle, notificationOptions);
  });

  // Handle notification click events
  self.addEventListener('notificationclick', function(event) {
    console.log('[firebase-messaging-sw.js] Notification click received.');

    event.notification.close();

    event.waitUntil(
      clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(clientList) {
        if (clients.openWindow) {
          const clickAction = event.notification.data?.click_action || '/';
          return clients.openWindow(clickAction);
        }
      })
    );
  });
}

initializeFirebase();

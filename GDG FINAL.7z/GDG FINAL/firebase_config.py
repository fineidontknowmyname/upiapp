import os
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

# Initialize Firebase if credentials are present
try:
    # Use environment variable for service account key path
    cred_path = os.environ.get('FIREBASE_CREDENTIAL_PATH', 'credentials.json')
    
    if os.path.exists(cred_path):
        cred = credentials.Certificate(cred_path)
        firebase_admin.initialize_app(cred)
        db = firestore.client()
    else:
        # If no credentials, create a mock for development
        print("Warning: Firebase credentials not found, using mock database")
        db = None
except Exception as e:
    print(f"Firebase initialization error: {e}")
    db = None

def firebase_store_data(collection_name, doc_id, data):
    """
    Store data in Firebase Firestore
    
    Args:
        collection_name (str): Collection name
        doc_id (str): Document ID
        data (dict): Data to store
    """
    if db is None:
        print(f"Mock storage: {collection_name}/{doc_id}: {data}")
        return
    
    try:
        # Add timestamp
        data['timestamp'] = datetime.now().isoformat()
        
        # Store in Firestore
        db.collection(collection_name).document(doc_id).set(data)
        
        # Also store in logs collection
        db.collection('scan_logs').add(data)
    except Exception as e:
        print(f"Firebase storage error: {e}")
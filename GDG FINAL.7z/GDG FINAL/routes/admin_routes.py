from flask import Blueprint, render_template, session, redirect, url_for, flash
from firebase_config import db

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard', methods=['GET'])
def admin_dashboard():
    if session.get('role') != 'admin':
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('auth.login'))
    
    logs = []
    
    # Only try to fetch logs if Firebase is configured
    if db:
        try:
            logs = [doc.to_dict() for doc in db.collection('scan_logs').stream()]
        except Exception as e:
            flash(f"Error fetching logs: {str(e)}", 'danger')
    
    return render_template('admin_dashboard.html', logs=logs)
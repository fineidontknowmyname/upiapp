from flask import Blueprint, render_template, request, session, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash

# Mock database for storing user credentials
# Replace this with a real database in production (e.g., Firebase, MongoDB, SQL)
users_db = {}

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """
    Handle user login.
    """
    error = None
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the user exists in the database
        user = users_db.get(email)
        if user and check_password_hash(user['password'], password):
            # Store user information in the session
            session['user_id'] = email
            session['role'] = user.get('role', 'user')  # Default role is 'user'
            flash('Login successful!', 'success')
            # Redirect based on role
            if session['role'] == 'admin':
                return redirect(url_for('admin.admin_dashboard'))
            return redirect(url_for('scan.scan_page'))
        else:
            error = "Invalid email or password"

    return render_template('login.html', error=error)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """
    Handle user registration.
    """
    error = None
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the email is already registered
        if email in users_db:
            error = "Email is already registered"
        else:
            # Store the user in the database with a hashed password
            users_db[email] = {
                'password': generate_password_hash(password),
                'role': 'user'  # Default role is 'user'
            }
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('auth.login'))

    return render_template('register.html', error=error)

@auth_bp.route('/logout')
def logout():
    """
    Handle user logout.
    """
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('auth.login'))
from flask import Blueprint, render_template, request, session, flash, redirect, url_for
from transaction_scanner import check_transaction
from firebase_config import firebase_store_data

scan_bp = Blueprint('scan', __name__)

@scan_bp.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@scan_bp.route('/check', methods=['GET', 'POST'])
def scan_page():
    result = None
    error = None
    
    # Check if user is logged in
    user_id = session.get('user_id')
    
    if request.method == 'POST':
        input_value = request.form.get('input')
        if not input_value:
            error = "Input is required"
        else:
            result = check_transaction({"input": input_value})
            
            # Store result with user ID if available
            if user_id:
                result['user_id'] = user_id
            
            firebase_store_data('scan_results', 'latest_result', result)
            
            # Flash appropriate message based on result
            if result['status'] == 'Safe':
                flash(f"The {result['type']} is safe to use", 'success')
            elif result['status'] == 'Suspicious' or result['status'] == 'Malicious':
                flash(f"Warning! The {result['type']} appears to be {result['status'].lower()}", 'danger')
            else:
                flash(f"Validation result: {result['status']}", 'info')
    
    return render_template('scan.html', result=result, error=error)
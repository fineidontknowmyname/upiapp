#transaction_scanner.py
import re
from safe_browsing import is_url_suspicious

def is_valid_upi(upi: str) -> bool:
    upi_regex = r"^[a-zA-Z0-9.-]{2,}@[a-zA-Z]{2,}$"
    return bool(re.match(upi_regex, upi))

def check_transaction(input_data: dict) -> dict:
    input_value = input_data.get('input', '')
    result = {"type": "unknown", "input": input_value, "status": "Unknown"}

    if is_valid_upi(input_value):
        result["type"] = "UPI"
        result["status"] = "Safe"
    elif input_value.startswith(('http://', 'https://')):
        result["type"] = "URL"
        result["status"] = is_url_suspicious(input_value)
    else:
        result["status"] = "Invalid input"

    return result
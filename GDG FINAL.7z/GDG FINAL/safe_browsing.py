import requests
import logging

def is_url_suspicious(url: str) -> str:
    """
    Check if a URL is suspicious using basic validation and potentially 
    external API services (simulated here).
    
    Args:
        url (str): The URL to check
        
    Returns:
        str: "Safe", "Suspicious", or "Malicious"
    """
    logging.info(f"Checking URL: {url}")
    
    # Basic validation
    if not url.startswith(('http://', 'https://')):
        return "Invalid URL format"
    
    # Check for common phishing indicators in URL
    suspicious_terms = ["login", "verify", "account", "secure", "banking", "update", "password"]
    suspicious_score = sum(1 for term in suspicious_terms if term in url.lower())
    
    # In a real implementation, you would call an API like Google Safe Browsing
    # Here we're just doing a simple simulation based on suspicious terms
    
    if suspicious_score >= 3:
        return "Malicious"
    elif suspicious_score >= 1:
        return "Suspicious"
    else:
        return "Safe"
# UPI Fraud Detection

A Flask-based web application to detect fraudulent UPI IDs and URLs.

## Features
- User authentication (login/register)
- Scan UPI IDs or URLs for fraud
- Admin dashboard to view scan logs

## Prerequisites
- Python 3.8+
- Git

## Setup Instructions
1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/upi-fraud-detection.git
   cd upi-fraud-detection